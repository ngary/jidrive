<?php

/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 6/18/2019
 * Time: 3:30 PM
 */

use Safaricom\Mpesa\Mpesa;
use App\Abstracts\Gateways;

class MpesaPayment extends Gateways
{
    protected $apiContext;
    static $paymentId = 'mpesa';

    public function __construct()
    {
        parent::__construct();
    }

    public static function getID()
    {
        return self::$paymentId;
    }

    public static function getName()
    {

        return __('Mpesa');
    }

    public static function getHtml()
    {
        return '';
    }

    public static function enable()
    {
        $enable = get_option('enable_' . self::$paymentId, 'off');
        return !!($enable == 'on');
    }

    public static function enableTestMode()
    {
        $enable = get_option(self::$paymentId . '_test_mode', 'off');
        return !!($enable == 'on');
    }

    public static function getLogo()
    {
        $img = get_option(self::$paymentId . '_logo');
        if (!$img) {
            return asset('/images/mpesa.png');
        }
        return get_attachment_url($img, 'full');
    }

    public static function getDescription()
    {
        $desc = get_option(self::$paymentId . '_description');
        return ($desc);
    }

    public static function getOptions()
    {
        // TODO: Implement setOptions() method.

        return [

            'title' => [
                'id' => 'sub_tab_' . self::$paymentId,
                'label' => self::getName()
            ],
            'content' => [
                [
                    'id' => 'enable_' . self::$paymentId,
                    'label' => __('Enable'),
                    'type' => 'on_off',
                    'std' => 'off',
                    'section' => 'sub_tab_' . self::$paymentId
                ],
                [
                    'id' => self::$paymentId . '_logo',
                    'label' => __('Logo'),
                    'type' => 'upload',
                    'section' => 'sub_tab_' . self::$paymentId
                ],
                [
                    'id' => self::$paymentId . '_test_mode',
                    'label' => __('Test Mode'),
                    'type' => 'on_off',
                    'std' => 'on',
                    'section' => 'sub_tab_' . self::$paymentId
                ],
                [
                    'id' => self::$paymentId . '_consumer_key',
                    'label' => __('Consumer Key'),
                    'type' => 'text',
                    'layout' => 'col-12 col-sm-6',
                    'section' => 'sub_tab_' . self::$paymentId
                ],
                [
                    'id' => self::$paymentId . '_consumer_secret',
                    'label' => __('Consumer Secret'),
                    'type' => 'text',
                    'layout' => 'col-12 col-sm-6',
                    'break' => true,
                    'section' => 'sub_tab_' . self::$paymentId
                ],
                [
                    'id' => self::$paymentId . '_short_code',
                    'label' => __('Short Code'),
                    'type' => 'text',
                    'layout' => 'col-12 col-sm-6',
                    'break' => true,
                    'section' => 'sub_tab_' . self::$paymentId
                ],
                [
                    'id' => self::$paymentId . '_pass_key',
                    'label' => __('Mpesa Pass Key'),
                    'type' => 'text',
                    'layout' => 'col-12 col-sm-6',
                    'break' => true,
                    'section' => 'sub_tab_' . self::$paymentId
                ],
                [
                    'id' => self::$paymentId . '_description',
                    'label' => __('Description'),
                    'type' => 'textarea',
                    'translation' => true,
                    'section' => 'sub_tab_' . self::$paymentId
                ],
            ]
        ];
    }

    public function setDefaultParams()
    {
        // TODO: Implement setDefaultParams() method.

        date_default_timezone_set(@date_default_timezone_get());

        $consumerKey = get_option(self::$paymentId . '_consumer_key');
        $consumerSecret = get_option(self::$paymentId . '_consumer_secret');
        $shortCode = get_option(self::$paymentId . '_short_code');
        $passkey = get_option(self::$paymentId . '_pass_key');

        $testMode = self::enableTestMode();
        $apiContext = array(
            'mode' => ($testMode) ? 'sandbox' : 'live',
            'log.LogEnabled' => false,
            'consumerKey' => $consumerKey,
            'consumerSecret' => $consumerSecret,
            'shortCode' => $shortCode,
            'passKey' => $passkey,
            'transactionType' => "CustomerPayBillOnline",
            'phone' => $this->clean($this->orderObject->phone),
            'description' => sprintf(__('Booking ID: %s'), $this->orderObject->booking_id),
            'invoice' => $this->orderObject->booking_id,
        );

        $this->apiContext = $apiContext;
    }

    public function setParams($params = [])
    {
        // TODO: Implement setParams() method.
        $currency = $this->getCurrencyUnit($this->orderObject->currency);

        $default = [
            'items' => [
                'name' => $this->orderObject->booking_description,
                'currency' => $currency,
                'quantity' => 1,
                'itemNumber' => $this->orderObject->booking_id,
                'price' => $this->convertPrice($this->orderObject->total, get_currency_by_unit($currency))
            ],
            'currency' => $currency,
            'total' => $this->convertPrice($this->orderObject->total, get_currency_by_unit($currency)),
            'description' => sprintf(__('Booking ID: %s'), $this->orderObject->booking_id),
            // 'returnUrl' => $this->successUrl(),
            // 'cancelUrl' => $this->cancelUrl(),
            'invoice' => uniqid()
        ];

        $params = wp_parse_args($params, $default);
        $this->params = $params;
    }

    public function validation()
    {
        // TODO: Implement validation() method.

        return true;
    }

    public function purchase($booking_id = false, $params = [])
    {
        $this->setOrderObject($booking_id);
        $this->setDefaultParams();
        $this->setParams($params);

        try {
            $res = Mpesa::STKPushSimulation($this->apiContext, $this->params);
            $array = json_decode($res[0]);
            if (isset($array->CheckoutRequestID)) {
                sleep(20);

                try {
                    $res = Mpesa::STKPushQuery($this->apiContext, $array->CheckoutRequestID);
                    $array = json_decode($res[0]);
                    // print_r($array);
                    if (isset($array->ResultCode) && $array->ResultCode == "0") {
                        do_action('hh_purchase_' . self::$paymentId, $this->params);
                        return [
                            'status' => 'completed',
                            'redirectUrl' => $this->successUrl(),
                            'message' => __(($array->ResultDesc) . ' The system is redirecting...')
                        ];
                    } else {
                        return [
                            'status' => 'canceled',
                            'redirectUrl' => $this->cancelUrl(),
                            'message' => __($array->ResultDesc)
                        ];
                    }
                } catch (Exception $ex) {
                    return [
                        'status' => 'incomplete',
                        'message' => sprintf(__('Get the error: Code %s - Message %s'), $ex->getCode(), $ex->getMessage())
                    ];
                }
            } else {
                return [
                    'status' => 'pending',
                    'message' => __('An error has occured')
                ];
            }
        } catch (Exception $ex) {
            return [
                'status' => 'Pending',
                'message' => sprintf(__('Get the error: Code %s - Message %s'), $ex->getCode(), $ex->getMessage())
            ];
        }
    }

    public function objectToArray($object)
    {
        if (!is_object($object) && !is_array($object)) {
            return $object;
        }
        return array_map('objectToArray', (array) $object);
    }

    public function completePurchase($booking_id = false, $params = [])
    {
        do_action('hh_complete_purchase_' . self::$paymentId, $this->params);
        return [
            'status' => 'incomplete'
        ];
    }

    public static function get_inst()
    {
        static $instance;
        if (is_null($instance)) {
            $instance = new self();
        }

        return $instance;
    }

    public function clean($string)
    {
        $string = str_replace(' ', '', $string); // Replaces all spaces.
        $newstring = preg_replace('/[^0-9\-]/', '', $string); // Removes special chars.
        if ($newstring[0] == '0') {
            return '254' . substr($newstring, 1);
        }
        return $newstring;
    }
}
