
<?php 
phpinfo();
?>