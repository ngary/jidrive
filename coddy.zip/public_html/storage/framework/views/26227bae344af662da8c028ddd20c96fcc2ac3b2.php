<a class="btn btn-success waves-effect waves-light" href="javascript:void(0)" data-toggle="modal"
   data-target="#hh-add-new-coupon-modal">
    <i class="ti-plus mr-1"></i>
    <?php echo e(__('Create New')); ?>

</a>
<div id="hh-add-new-coupon-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <form class="form form-action relative form-translation" action="<?php echo e(dashboard_url('add-new-coupon')); ?>" data-validation-id="form-add-new-coupon">
            <?php echo $__env->make('common.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('Add new Coupon')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×
                    </button>
                </div>
                <div class="modal-body">
                    <?php
                    show_lang_section('mb-2');
                    $langs = get_languages_field();
                    ?>
                    <div class="form-group">
                        <label for="coupon_code">
                            <?php echo e(__('Coupon Code')); ?>

                        </label>
                        <input type="text" class="form-control has-validation"
                               data-validation="required" id="coupon_code" name="coupon_code"
                               placeholder="<?php echo e(__('Recommended: Letters, numbers')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="coupon_description">
                            <?php echo e(__('Coupon Description')); ?>

                        </label>
                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <textarea name="coupon_description<?php echo e(get_lang_suffix($item)); ?>"
                                      id="coupon_description<?php echo e(get_lang_suffix($item)); ?>"
                                      class="form-control <?php echo e(get_lang_class($key, $item)); ?>"
                                      placeholder="<?php echo e(__('Enter more detail')); ?>"
                                      <?php if(!empty($item)): ?> data-lang="<?php echo e($item); ?>" <?php endif; ?>></textarea>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label for="coupon_type">
                                    <?php echo e(__('Coupon Type')); ?>

                                </label><br/>
                                <select name="coupon_type" id="coupon_type" class="wide"
                                        data-plugin="customselect">
                                    <option value="fixed"><?php echo e(__('Fixed')); ?></option>
                                    <option value="percent"><?php echo e(__('Percent')); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label for="coupon_price">
                                    <?php echo e(__('Coupon Price')); ?>

                                </label>
                                <input type="number" class="form-control has-validation" min="0"
                                       data-validation="required|numeric" id="coupon_price"
                                       name="coupon_price"
                                       placeholder="<?php echo e(__('Price')); ?>">
                            </div>
                        </div>
                    </div>
                        <div class="row">
                            <div class="col-12 col-sm-6">
                                <div class="form-group">
                                    <label for="coupon_service_type_update"><?php echo e(__('Service Type')); ?></label>
                                    <select id="coupon_service_type_update" class="wide"
                                            data-plugin="customselect" name="coupon_service_type">
                                        <option value=""><?php echo e(__('Apply All Services')); ?></option>
                                        <?php
                                        $services = get_posttypes(false);
                                        foreach ($services as $key => $service) {
                                        ?>
                                        <option value="<?php echo e($key); ?>"><?php echo e($service['name']); ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    <div class="row">
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label for="coupon_start">
                                    <?php echo e(__('Start Date')); ?>

                                </label>
                                <input type="text" class="form-control has-validation"
                                       data-validation="required" id="coupon_start"
                                       name="coupon_start" data-plugin="datepicker"
                                       placeholder="<?php echo e(__('Start Date')); ?>">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="form-group">
                                <label for="coupon_end">
                                    <?php echo e(__('End Date')); ?>

                                </label>
                                <input type="text" class="form-control has-validation"
                                       data-validation="required" id="coupon_end"
                                       name="coupon_end" data-plugin="datepicker"
                                       placeholder="<?php echo e(__('End Date')); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit"
                            class="btn btn-info waves-effect waves-light"><?php echo e(__('Add New')); ?>

                    </button>
                </div>
            </div>
        </form>
    </div>
</div><!-- /.modal -->
<?php /**PATH /var/www/bookings/html/app/Views/dashboard/components/quick-add-coupon.blade.php ENDPATH**/ ?>