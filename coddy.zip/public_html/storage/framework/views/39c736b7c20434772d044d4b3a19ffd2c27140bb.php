<?php
$logo_footer = get_option('footer_logo');
if (empty($logo_footer)) {
    $logo_footer = get_option('logo');
}
$list_social = get_option('list_social');
$screen = current_screen();
$setup_mailc_api = get_option('mailchimp_api_key');
$setup_mailc_list_id = get_option('mailchimp_list');
enqueue_script('nice-select-js');
enqueue_style('nice-select-css');
?>
</div>
<footer id="footer" class="<?php echo e($screen == 'home-search-result' ? 'hide-footer' : ''); ?>">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <?php if(!empty($logo_footer)): ?>
                    <img src="<?php echo e(get_attachment_url($logo_footer)); ?>" alt="footer logo" class="footer-logo"/>
                <?php endif; ?>
                <?php if(!empty($list_social)): ?>
                    <ul class="social">
                        <?php $__currentLoopData = $list_social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e($item['social_link']); ?>">
                                    <?php echo get_icon($item['social_icon']); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
            <div class="col-lg-5 col-md-12">
                <div class="row">
                    <div class="col-lg-6 col-md-12">
                        <h4 class="footer-title"><?php echo e(get_option('footer_menu1_label')); ?></h4>
                        <?php
                        $menu_id = get_option('footer_menu1');
                        get_nav_by_id($menu_id);
                        ?>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <h4 class="footer-title"><?php echo e(get_option('footer_menu2_label')); ?></h4>
                        <?php
                        $menu_id = get_option('footer_menu2');
                        get_nav_by_id($menu_id);
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12">
                <?php if(!empty($setup_mailc_api) && !empty($setup_mailc_list_id)): ?>
                    <h4 class="footer-title"><?php echo e(get_option('footer_subscribe_label')); ?></h4>
                    <p><?php echo e(get_option('footer_subscribe_description')); ?></p>
                    <form action="<?php echo e(url('subscribe-email')); ?>" class="subscribe-form form-sm form-action"
                          data-validation-id="form-subscribe"
                          method="post" data-reload-time="1000">
                        <input type="email" id="mc-email" name="email" placeholder="<?php echo e(__('Enter your email')); ?>"
                               class="form-control has-validation" data-validation="required"/>
                        <button type="submit"><i class="fe-arrow-right"></i> <span class="hh-loading"></span></button>
                        <div class="form-message"></div>
                    </form>
                <?php else: ?>
                    <small><i><?php echo e(__('Please setup Mailchimp in Settings')); ?></i></small>
                <?php endif; ?>
            </div>
        </div>
        <div class="copy-right d-flex align-items-center justify-content-between">
            <div class="clearfix">
                <?php echo balanceTags(get_option('copy_right')); ?>

            </div>
        </div>
    </div>
</footer>
</div>
<?php do_action('footer'); ?>
<?php do_action('init_footer'); ?>
<?php do_action('init_frontend_footer'); ?>
<script src="<?php echo e(asset('js/frontend.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\Xampp7.3.7\htdocs\awebooking\app\Views/frontend/components/footer.blade.php ENDPATH**/ ?>