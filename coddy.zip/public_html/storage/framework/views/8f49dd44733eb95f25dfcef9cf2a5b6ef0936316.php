<?php echo $__env->make('frontend.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
enqueue_style('mapbox-gl-css');
enqueue_style('mapbox-gl-geocoder-css');
enqueue_script('mapbox-gl-js');
enqueue_script('mapbox-gl-geocoder-js');
enqueue_script('search-car-js');
$layout = isset($_GET['layout']) ? $_GET['layout'] : 'grid';
$showmap = (isset($_GET['showmap']) && $_GET['showmap'] == 'no') ? 'no' : 'yes';
$checkIn = isset($_GET['checkIn']) ? $_GET['checkIn'] : '';
$checkOut = isset($_GET['checkOut']) ? $_GET['checkOut'] : '';
$checkInTime = isset($_GET['checkInTime']) ? $_GET['checkInTime'] : '12:00 am';
if ($checkIn == $checkOut) {
    $checkOutTime = isset($_GET['checkOutTime']) ? $_GET['checkOutTime'] : '12:15 am';
} else {
    $checkOutTime = isset($_GET['checkOutTime']) ? $_GET['checkOutTime'] : '12:00 am';
}
?>
<div class="hh-search-result hh-search-result-car"
     data-url="<?php echo e(get_car_search_page()); ?>"
     data-checkin="<?php echo e($checkIn); ?>"
     data-checkout="<?php echo e($checkOut); ?>"
     data-checkin-time="<?php echo e($checkInTime); ?>"
     data-checkout-time="<?php echo e($checkOutTime); ?>">
    <?php echo $__env->make('frontend.car.search.search-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="hh-search-content-wrapper <?php if($showmap == 'no'): ?> no-map <?php endif; ?>">
        <?php echo $__env->make('common.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="hh-search-results-render" data-url="<?php echo e(get_car_search_page()); ?>">
            <div class="render">
                <div class="d-flex align-items-center justify-content-between">
                    <div class="hh-search-results-string">
                        <span class="item-found"><?php echo e(__('Searching car...')); ?></span>
                    </div>
                    <div class="item-layout">
                        <span class="<?php if($layout == 'grid'): ?> active <?php endif; ?>" data-layout="grid"><i
                                class="ti-layout-grid2"></i></span>
                        <span class="<?php if($layout == 'list'): ?> active <?php endif; ?>" data-layout="list"><i
                                class="ti-view-list-alt"></i></span>
                    </div>
                </div>
                <div class="hh-search-content row">
                    <div class="service-item list"></div>
                </div>
                <div class="hh-search-pagination mt-0"></div>
            </div>
        </div>
        <div class="hh-search-results-map">
            <?php
            $lat = request()->get('lat');
            $lng = request()->get('lng');
            $zoom = request()->get('zoom', 10);
            $in_map = true;
            ?>
            <div class="hh-mapbox-search" data-lat="<?php echo e($lat); ?>"
                 data-lng="<?php echo e($lng); ?>" data-zoom="<?php echo e($zoom); ?>"></div>
            <div class="hh-close-map-popup" id="hide-map-mobile"><?php echo e(__('Close')); ?></div>
            <div class="hh-map-tooltip">
                <div class="checkbox checkbox-success">
                    <input id="chk-map-move" type="checkbox" name="map_move" value="1">
                    <label for="chk-map-move"><?php echo e(__('Search as I move the map')); ?></label>
                </div>
                <?php echo $__env->make('common.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('frontend.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/bookings/html/app/Views/frontend/car/search/search.blade.php ENDPATH**/ ?>