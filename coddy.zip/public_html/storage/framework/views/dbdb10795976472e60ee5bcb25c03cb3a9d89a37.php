<?php
$layout = (!empty($layout)) ? $layout : 'col-12';
if (empty($value) && !is_array($value)) {
    $value = $std;
}
$idName = str_replace(['[', ']'], '_', $id);
$langs = $translation == false ? [""] : get_languages_field();
$value = maybe_unserialize($value);
?>

<div id="setting-<?php echo e($idName); ?>" data-condition="<?php echo e($condition); ?>"
     data-unique="<?php echo e($unique); ?>"
     data-operator="<?php echo e($operation); ?>"
     class="form-group mb-3 col <?php echo e($layout); ?> field-<?php echo e($type); ?>">
    <label for="<?php echo e($idName); ?>">
        <?php echo e(__($label)); ?>

        <?php if(!empty($desc)): ?>
            <i class="dripicons-information field-desc" data-toggle="popover" data-placement="right"
               data-trigger="hover"
               data-content="<?php echo e(__($desc)); ?>"></i>
        <?php endif; ?>
    </label><br/>

    <div class="checkbox-wrapper">
        <?php if(!empty($choices)): ?>
            <?php if(!is_array($choices)): ?>
                <?php
                $choices = get_terms($choices, true);
                ?>
            <?php endif; ?>
            <?php if(!empty($choices)): ?>
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                        <tr>
                            <th>
                                <div class="checkbox checkbox-success hh-check-all">
                                    <input type="checkbox" id="hh-checkbox-all">
                                    <label for="hh-checkbox-all">
                                        <span><?php echo e(__('Name')); ?></span>
                                    </label>
                                </div>
                            </th>
                            <th><?php echo e(__('Base Price')); ?></th>
                            <th><?php echo e(__('Custom Price')); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $term_id = $item->term_id;
                            $custom_price = '';
                            $choose = 'no';
                            if (isset($value[$term_id])) {
                                $choose = $value[$term_id]['choose'];
                                if (!empty($value[$term_id]['custom'])) {
                                    $custom_price = $value[$term_id]['price'];
                                }
                            }
                            ?>
                            <tr>
                                <th scope="row" class="align-middle">
                                    <div class="checkbox  checkbox-success ">
                                        <input type="checkbox" <?php if($choose == 'yes'): ?> checked
                                               <?php endif; ?> name="<?php echo e($idName); ?>[id][<?php echo e($term_id); ?>]" value="<?php echo e($term_id); ?>"
                                               id="car_equipment-<?php echo e($term_id); ?>" class="hh-check-all-item">
                                        <label for="car_equipment-<?php echo e($term_id); ?>">
                                            <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="<?php echo e(get_lang_class($key, $val)); ?>"
                                                      <?php if(!empty($val)): ?> data-lang="<?php echo e($val); ?>" <?php endif; ?>>
                                                <?php echo balanceTags(get_translate($item->term_title, $val)); ?>

                                            </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </label>
                                    </div>
                                </th>
                                <td class="align-middle"><?php echo e(convert_price($item->term_price)); ?></td>
                                <td class="align-middle">
                                    <input type="text" value="<?php echo e($custom_price); ?>" name="<?php echo e($idName); ?>[price][<?php echo e($term_id); ?>]"
                                           class="form-control p-1 w-50">
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <?php echo e(__('No Data')); ?>

            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php if($break): ?>
    <div class="w-100"></div> <?php endif; ?>
<?php /**PATH /var/www/bookings/html/app/Views/options/fields/term_price.blade.php ENDPATH**/ ?>