<?php
$css = '
        .text-center{
            text-align: center;
        }
        .hh-email-wrapper{
            width: 95%;
            max-width: 650px;
            margin: 20px auto;
            border: 1px solid #EEE;
            padding: 20px;
        }
        .hh-email-wrapper .header-email table{
            width: 100%;
            border: none;
            table-layout: fixed;
        }
        .hh-email-wrapper .header-email .logo{
           width: 60px;
           height: auto;
        }
        .hh-email-wrapper .header-email .description{
            font-size: 18px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 0;
            margin-top: 0;
        }
        .content-email{
            padding-top: 20px;
            padding-bottom: 30px;
        }

        .booking-detail{
            margin-top: 30px;
            padding: 10px 20px;
            border: 1px solid #EEE;
        }
        .booking-detail .item{
            padding-top: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #EEE;
            display: flex;
        }
        .booking-detail .item .title{
            display: inline-block;
            font-size: 15px;
            width: 35%;
        }
        .booking-detail .item .info{
            display: inline-block;
            font-size: 15px;
            font-weight: bold;
            width: 65%;
        }
        .booking-detail .client-info .info{
            font-weight: normal;
        }
        .booking-detail .client-info .info p{
            margin-top: 0;
        }
        .button-primary{
            display: inline-block;
            padding: 10px 20px;
            border: 1px solid #f8546d;
            background: #f8546d;
            color: #FFF;
            text-align: center;
        }
        .confirmation-button{
            margin-top: 30px;
            text-transform: uppercase;
            text-decoration: none;
        }

        .footer-email{
            border-top: 1px solid #EEE;
            padding: 30px 0;
        }
        .cart-list{
            margin-top: 0;
            padding-left: 0;
        }
        .cart-list li{
            padding-top: 5px;
            padding-bottom: 5px;
            border-bottom: 1px dashed #CCC;
        }
        .cart-list li span{
            display: inline-block;
            width: 50%;
        }
        .cart-list li span + span{
            display: inline-block;
            width: auto;
            text-align: right;
        }
        .booking-status{
            padding: 5px 11px;
            font-size: 12px;
            color: #FFF;
        }
        .booking-status.completed {
          background: #1abc9c;
        }

        .booking-status.incomplete {
          background: #f7b84b;
        }

        .booking-status.canceled {
          background: rgba(255, 80, 66, 0.78);
        }

        .booking-status.pending {
          background: #516a77;
        }

        .booking-status.refunded {
          background: #222;
        }
    ';

$service_data = get_booking_data($booking->ID, 'serviceObject');
start_get_view();
?>
<div class="hh-email-wrapper">
    <div class="header-email">
        <table>
            <tr>
                <td style="text-align: left">
                    <?php
                    $logo = get_option('email_logo');
                    $logo_url = get_attachment_url($logo);
                    ?>
                    <a href="<?php echo e(url('/')); ?>" target="_blank">
                        <img src="<?php echo e($logo_url); ?>" alt="<?php echo e(get_option('site_description')); ?>" class="logo">
                    </a>
                </td>
                <td style="text-align: right">
                    <h4 class="description"><?php echo e(get_option('site_name')); ?></h4>
                </td>
            </tr>
        </table>
    </div>
    <div class="content-email">
        <?php if($for == 'customer'): ?>
            <p><?php echo e(__('Hello')); ?> <strong><?php echo e($booking->first_name); ?> <?php echo e($booking->last_name); ?></strong>,</p>
            <p><?php echo e(__('Thank you for using our service!')); ?></p>
            <p><?php echo e(__('Here is your booking information:')); ?></p>
        <?php elseif($for == 'admin'): ?>
            <?php
            $admin_data = get_admin_user();
            ?>
            <p><?php echo sprintf(__('Hello %s'), '<strong>' . $admin_data->first_name . ' ' . $admin_data->last_name . '</strong>'); ?>

                ,</p>
            <p><?php echo e(__('There is a new booking on your system')); ?></p>
        <?php elseif($for == 'partner'): ?>
            <?php
            $partner_data = get_user_by_id($booking->owner);
            ?>
            <p><?php echo sprintf(__('Hello %s'), '<strong>'. $partner_data->first_name . ' ' . $partner_data->last_name .'</strong>'); ?>

                ,</p>
            <p><?php echo sprintf(__('%s has booked your service.'), '<strong>' . $booking->first_name . ' ' . $booking->last_name . '</strong>'); ?></p>
            <p><?php echo e(__('Here is the details of the booking:')); ?></p>
        <?php endif; ?>
        <div class="booking-detail">
            <div class="item">
                <span class="title"><?php echo e(__('Booking ID:')); ?></span>
                <span class="info"><?php echo e($booking->booking_id); ?></span>
            </div>
            <div class="item">
                <span class="title"><?php echo e(__('Name:')); ?></span>
                <span class="info"><?php echo e(get_translate($service_data->post_title)); ?></span>
            </div>
            <div class="item">
                <span class="title"><?php echo e(__('Amount:')); ?></span>
                <span class="info"><?php echo e(convert_price($booking->total)); ?></span>
            </div>
            <div class="item">
                <span class="title"><?php echo e(__('Payment Method:')); ?></span>
                <span class="info">
                     <?php
                    $paymentID = $booking->payment_type;
                    $paymentObject = get_payments($paymentID);
                    ?>
                    <?php echo e($paymentObject::getName()); ?>

                </span>
            </div>
            <div class="item">
                <span class="title"><?php echo e(__('Status:')); ?></span>
                <span class="info">
                    <?php
                    $status = $booking->status;
                    $status_info = booking_status_info($status);
                    ?>
                    <span class="booking-status <?php echo e($status); ?>"><?php echo e(get_translate(__($status_info['label']))); ?></span>
                </span>
            </div>
            <div class="item">
                <span class="title"><?php echo e(__('Created At:')); ?></span>
                <span class="info"><?php echo e(date(hh_date_format(), $booking->created_date)); ?></span>
            </div>
            <div class="item">
                <span class="title"><?php echo e(__('Price Detail:')); ?></span>
                <div class="info">
                    <?php
                    $cartData = get_booking_data($booking->ID, 'cartData');
                    $checkout_data = get_booking_data($booking->ID);
                    ?>
                    <ul class="cart-list">
                        <?php
                        $checkIn = $cartData['startDateTime'];
                        $checkOut = $cartData['endDateTime'];
                        $number = $cartData['number'];
                        $booking_type = isset($cartData['bookingType']) ? $cartData['bookingType'] : 'day';
                        ?>
                        <?php if($number > 0): ?>
                            <li>
                                <span><?php echo e(__('Number')); ?></span>
                                <span> <?php echo e($number); ?>  </span>
                            </li>
                        <?php endif; ?>
                        <li>
                            <span><?php echo e(__('From')); ?></span>
                            <span>
                                <?php echo e(date(hh_date_format(true), $checkIn)); ?>

                            </span>
                        </li>
                        <li>
                            <span><?php echo e(__('To')); ?></span>
                            <span>
                                <?php echo e(date(hh_date_format(true), $checkOut)); ?>

                            </span>
                        </li>
                        <?php
                        $number_hour = isset($cartData['numberHour']) ? $cartData['numberHour'] : 0;
                        $number_day = isset($cartData['numberDay']) ? $cartData['numberDay'] : 0;
                        ?>
                        <?php if(($booking_type == 'hour' && $number_hour > 0) || ($booking_type == 'day' && $number_day > 0)): ?>
                            <li>
                                <span><?php echo e(__('Duration')); ?></span>
                                <span>
                                <?php if($booking_type == 'hour'): ?>
                                        <?php echo e(_n("[0::%s hours][1::%s hour][2::%s hours]",  $number_hour)); ?>

                                    <?php elseif($booking_type == 'day'): ?>
                                        <?php echo e(_n("[0::%s days][1::%s day][2::%s days]",  $number_day)); ?>

                                    <?php endif; ?>
                            </span>
                            </li>
                        <?php endif; ?>
                        <?php if(!empty($cartData['equipmentData'])): ?>
                            <li>
                                <span style="vertical-align: middle"><?php echo e(__('Equipments')); ?></span>
                                <span style="vertical-align: middle">
                                <?php $__currentLoopData = $cartData['equipmentData']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p style="text-align: left">
                                        <?php echo e(get_translate($eq->term_title)); ?>

                                    </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                            </li>
                        <?php endif; ?>

                        <?php if(isset($cartData['insuranceData']) && !empty($cartData['insuranceData'])): ?>
                            <li>
                                <span style="vertical-align: middle"><?php echo e(__('Insurance Plan')); ?></span>
                                <span style="vertical-align: middle">
                                <?php $__currentLoopData = $cartData['insuranceData']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p style="text-align: left">
                                        <?php echo e(get_translate($ip['name'])); ?>

                                    </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <ul class="menu cart-list">
                        <?php
                        $basePrice = $checkout_data['basePrice'];
                        $subTotalPrice = $checkout_data['subTotal'];
                        $equipmentPrice = isset($checkout_data['equipmentPrice']) ? $checkout_data['equipmentPrice'] : 0;
                        $insurancePrice = isset($checkout_data['insurancePrice']) ? $checkout_data['insurancePrice'] : 0;
                        $tax = $checkout_data['tax'];
                        $coupon = isset($checkout_data['couponPrice']) ? $checkout_data['couponPrice'] : '';
                        ?>
                        <li>
                            <span><?php echo e(__('Price Car Rental')); ?></span>
                            <span><?php echo e(convert_price($basePrice)); ?></span>
                        </li>
                        <?php if($equipmentPrice > 0): ?>
                            <li>
                                <span><?php echo e(__('Equipment Price')); ?></span>
                                <span><?php echo e(convert_price($equipmentPrice)); ?></span>
                            </li>
                        <?php endif; ?>

                        <?php if($insurancePrice > 0): ?>
                            <li>
                                <span><?php echo e(__('Insurance Price')); ?></span>
                                <span><?php echo e(convert_price($insurancePrice)); ?></span>
                            </li>
                        <?php endif; ?>

                        <?php if(!empty($coupon)): ?>
                            <li>
                                <span><?php echo e(__('Coupon')); ?></span>
                                <span>-<?php echo e($coupon); ?></span>
                            </li>
                        <?php endif; ?>
                        <li>
                            <span><?php echo e(__('Sub total')); ?></span>
                            <span><?php echo e(convert_price($subTotalPrice)); ?></span>
                        </li>
                        <?php
                        $tax_value = (float)$checkout_data['tax']['tax'];
                        if($tax_value > 0):
                        ?>
                        <li class="divider">
                            <span><?php echo e(__('Tax')); ?>

                                <span class="text-muted">
                                    <?php if($checkout_data['tax']['included'] == 'on'): ?>
                                        <?php echo e(__('(included)')); ?>

                                    <?php endif; ?>
                                </span>
                            </span>
                            <span><?php echo e($tax_value); ?>%</span>
                        </li>
                        <?php endif; ?>
                        <li class="amount">
                            <span><?php echo e(__('Amount')); ?></span>
                            <span><?php echo e(convert_price($checkout_data['amount'])); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            <?php if($for == 'customer'): ?>
                <div class="item client-info">
                    <span class="title"><?php echo e(__('Your information:')); ?></span>
                    <?php
                    $user_data = get_booking_data($booking->ID, 'user_data');
                    ?>
                    <span class="info">
                    <p><?php echo e($user_data['firstName']); ?> <?php echo e($user_data['lastName']); ?></p>
                    <p><?php echo e($user_data['email']); ?></p>
                    <p><?php echo e($user_data['phone']); ?></p>
                    <p><?php echo e($user_data['address']); ?> | <?php echo e($user_data['city']); ?> | <?php echo e($user_data['postCode']); ?></p>
                    <?php if($booking->note): ?>
                            <p><?php echo e(__('Note:')); ?> <?php echo e($booking->note); ?></p>
                        <?php endif; ?>
                </span>
                </div>
            <?php endif; ?>
        </div>
        <div class="text-center">
            <a class="button-primary confirmation-button"
               href="<?php echo e(dashboard_url('all-booking')); ?>"><?php echo e(__('Your Bookings')); ?></a>
        </div>
    </div>
    <div class="footer-email">
        &copy; <?php echo e(date('Y')); ?> - <?php echo e(get_option('site_name')); ?> | <?php echo e(get_option('site_description')); ?>

    </div>
</div>
<?php
$content = end_get_view();
$render = new Emogrifier();
$render->setHtml($content);
$render->setCss($css);
$mergedHtml = $render->emogrify();
$mergedHtml = str_replace('<!DOCTYPE html>', '', $mergedHtml);
unset($render);
?>
<?php echo balanceTags($mergedHtml); ?>

<?php /**PATH /home/admin/web/ji-drive.com/public_html/app/Views/frontend/email/car/booking-detail.blade.php ENDPATH**/ ?>